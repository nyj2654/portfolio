var index = 0;
window.onload = function() {
    slideShow();
}

function slideShow() {
    var i;
    var x = document.getElementsByClassName("img1");
    for(i=0;i<x.length;i++) {
        x[i].style.display = "none";
    }
    index++;
    if(index > x.length) {
        index=1;
    }
    x[index-1].style.display = "block";
    setTimeout(slideShow, 3000);
}

var modalbtn = document.querySelector('.modalbtn');
var deletebtn = document.querySelector('.btn');
var login = document.querySelector('.login-modal');
var modalbg = document.querySelector('#header .modal-bg');

modalbtn.addEventListener('click',function() {
    login.style.display = "block";
    modalbg.style.display = "block";
})

deletebtn.addEventListener('click',function() {
    login.style.display = "none";
    modalbg.style.display = "none";
})
