jQuery(document).ready(function() {
    $(document).ready(function () {
        $(".submenu").hide();
        $(".mainmenu>li")
          .mouseover(function () {
            $(this).find(".submenu").stop().slideDown(300);
          })
          .mouseout(function () {
            $(this).find(".submenu").stop().slideUp(300);
          });
      });

    $('.imgslide a:gt(0)').hide();
    setInterval(function(){
        $('.imgslide a:first-child').fadeOut()
        .next("a").fadeIn().end()
        .appendTo('.imgslide');
    },2500);

    $(".list li:first").click(function() {
        $(".popup").addClass("active");
    });
    $(".btn").click(function() {
        $(".popup").removeClass("active");
    });
});